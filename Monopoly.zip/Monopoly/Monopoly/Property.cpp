#include "Property.h"



Property::Property()
{
}


Property::~Property()
{
}
