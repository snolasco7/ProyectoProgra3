#include <SFML/Graphics.hpp>
#include "MonopolyTable.h"

using namespace std;

int main() {
	MonopolyTable();
}