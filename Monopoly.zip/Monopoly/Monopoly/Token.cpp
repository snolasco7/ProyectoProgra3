#include "Token.h"



Token::Token()
{
}


Token::~Token()
{
}
