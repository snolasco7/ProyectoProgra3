#pragma once
#include <String>
#include "Property.h"
#include <SFML/Graphics.hpp>

using namespace std;

class Bank
{
public:
	int money;
	Bank();
	~Bank();
};

